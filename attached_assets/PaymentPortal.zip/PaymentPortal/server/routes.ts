import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { paymentFormSchema } from "@shared/schema";
import { sendPaymentEmail } from "./emailService";

export async function registerRoutes(app: Express): Promise<Server> {
  // Payment route
  app.post("/api/payment", async (req, res) => {
    try {
      // Validate request body
      const validationResult = paymentFormSchema.safeParse(req.body);
      
      if (!validationResult.success) {
        return res.status(400).json({ 
          message: "Invalid payment information", 
          errors: validationResult.error.errors 
        });
      }
      
      const paymentData = validationResult.data;
      
      // Send email with payment information
      await sendPaymentEmail(paymentData);
      
      // Return success response
      return res.status(200).json({ 
        message: "Payment information received successfully" 
      });
    } catch (error) {
      console.error("Error processing payment:", error);
      return res.status(500).json({ 
        message: "An error occurred while processing your payment information" 
      });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
