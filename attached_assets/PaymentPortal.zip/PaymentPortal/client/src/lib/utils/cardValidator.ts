export function formatCardNumber(value: string): string {
  const cleanValue = value.replace(/\D/g, '');
  let formatted = '';
  
  for (let i = 0; i < cleanValue.length; i++) {
    if (i > 0 && i % 4 === 0) {
      formatted += ' ';
    }
    formatted += cleanValue[i];
  }
  
  return formatted;
}

export function detectCardType(number: string): string {
  // Detect card type based on first digits
  if (number.startsWith('4')) {
    return 'visa';
  } else if (/^5[1-5]/.test(number)) {
    return 'mastercard';
  } else if (/^3[47]/.test(number)) {
    return 'amex';
  } else if (/^6(?:011|5)/.test(number)) {
    return 'discover';
  }
  return '';
}

export function validateCardNumber(number: string): boolean {
  const regex = new RegExp('^[0-9]{16}$');
  if (!regex.test(number.replace(/\s/g, ''))) {
    return false;
  }
  
  // Luhn algorithm for card number validation
  let sum = 0;
  let shouldDouble = false;
  
  // Loop through values starting from the rightmost side
  for (let i = number.replace(/\s/g, '').length - 1; i >= 0; i--) {
    let digit = parseInt(number.replace(/\s/g, '')[i]);

    if (shouldDouble) {
      digit = digit * 2;
      if (digit > 9) {
        digit = digit - 9;
      }
    }

    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return (sum % 10) === 0;
}

export function validateExpiry(value: string): boolean {
  // Check if it matches MM/YY pattern
  if (!/^\d{2}\/\d{2}$/.test(value)) {
    return false;
  }
  
  const [month, year] = value.split('/');
  const currentYear = new Date().getFullYear() % 100;
  const currentMonth = new Date().getMonth() + 1;
  
  const monthNum = parseInt(month, 10);
  const yearNum = parseInt(year, 10);
  
  // Validate month is between 1-12
  if (monthNum < 1 || monthNum > 12) {
    return false;
  }
  
  // Check if card is expired
  if (yearNum < currentYear || (yearNum === currentYear && monthNum < currentMonth)) {
    return false;
  }
  
  return true;
}

export function validateCVV(value: string, cardType: string = 'visa'): boolean {
  // Amex CVVs are 4 digits, others are 3
  const cvvLength = cardType === 'amex' ? 4 : 3;
  return new RegExp(`^[0-9]{${cvvLength}}$`).test(value);
}
