import React from "react";

export function VisaLogo({ className = "" }: { className?: string }) {
  return (
    <svg 
      className={className}
      width="50"
      height="20"
      viewBox="0 0 50 20"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      {/* Yellow triangle accent */}
      <path d="M19.5 2L18 5.2L5 20H25L19.5 2Z" fill="#F7B600"/>
      {/* Main VISA text */}
      <path d="M21.5 4L15.5 18H11L8.5 6.5C8.5 6.5 8.2 5.5 7.2 5C6.2 4.5 4 3.8 4 3.8H3.9L3.9 3.5H9.5L12 16L16 4H21.5Z" fill="#0057A0"/>
      <path d="M27 4L24.5 18H20.5L23 4H27Z" fill="#0057A0"/>
      <path d="M39 8C39 5.8 37.2 4 33.5 4C31.2 4 29 4.5 29 4.5L28.5 8C28.5 8 30.7 7.2 32.7 7.2C33.7 7.2 34.7 7.5 34.7 8.2C34.7 9.5 31.7 9.5 31.7 9.5C28.8 9.8 26.5 11.5 26.5 14.5C26.5 17.2 28.7 18.5 31.5 18.5C34.7 18.5 35.7 17 35.7 17L35.5 18H39.7L41.5 8.2C41.5 8.2 41.6 8 39 8ZM35.5 13.5C35.5 14.7 34.5 16 32.8 16C31.8 16 31.1 15.4 31.1 14.5C31.1 13.2 32.1 12.5 33.6 12.5C34.2 12.5 34.8 12.7 35.5 12.7V13.5Z" fill="#0057A0"/>
      <path d="M46 4L42 18H38L42 4H46Z" fill="#0057A0"/>
    </svg>
  );
}

export function MastercardLogo({ className = "" }: { className?: string }) {
  return (
    <svg 
      className={className}
      width="25"
      height="16"
      viewBox="0 0 25 16"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path d="M9 14C6.794 14 5 12.206 5 10C5 7.794 6.794 6 9 6C9.732 6 10.41 6.212 11 6.566C10.41 6.212 9.732 6 9 6C6.794 6 5 7.794 5 10C5 12.206 6.794 14 9 14Z" fill="#EA001B"/>
      <path d="M9 6C9.732 6 10.41 6.212 11 6.566C11.59 6.92 12.063 7.422 12.391 8.023C12.782 8.746 13 9.572 13 10.444C13 11.316 12.782 12.142 12.391 12.865C12.063 13.466 11.59 13.968 11 14.322C10.41 14.676 9.732 14.888 9 14.888C6.794 14.888 5 13.094 5 10.888C5 8.682 6.794 6.888 9 6.888C9.732 6.888 10.41 7.1 11 7.454C11.59 7.808 12.063 8.31 12.391 8.911C12.782 9.634 13 10.46 13 11.332C13 12.204 12.782 13.03 12.391 13.753C12.063 14.354 11.59 14.856 11 15.21C11.59 14.856 12.063 14.354 12.391 13.753C12.782 13.03 13 12.204 13 11.332C13 10.46 12.782 9.634 12.391 8.911C12.063 8.31 11.59 7.808 11 7.454C11.59 7.808 12.063 8.31 12.391 8.911C12.782 9.634 13 10.46 13 11.332C13 12.204 12.782 13.03 12.391 13.753C12.063 14.354 11.59 14.856 11 15.21C11.59 14.856 12.063 14.354 12.391 13.753C12.782 13.03 13 12.204 13 11.332C13 10.46 12.782 9.634 12.391 8.911C12.063 8.31 11.59 7.808 11 7.454" fill="#F79F1A"/>
      <path d="M16 14C18.206 14 20 12.206 20 10C20 7.794 18.206 6 16 6C13.794 6 12 7.794 12 10C12 12.206 13.794 14 16 14Z" fill="#FF5F00"/>
    </svg>
  );
}

export function AmexLogo({ className = "" }: { className?: string }) {
  return (
    <svg 
      className={className}
      width="25"
      height="16"
      viewBox="0 0 25 16"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <rect width="25" height="16" rx="1" fill="#016FD0" />
      <path d="M3 9.5V6.5H5L5.5 7.5L6 6.5H8V9.5H7V7L6 9H5L4 7V9.5H3Z" fill="white"/>
      <path d="M8.5 9.5L10 6.5H11.5L13 9.5H11.5L11.25 9H10.25L10 9.5H8.5ZM10.5 8H11L10.75 7.5L10.5 8Z" fill="white"/>
      <path d="M13.5 9.5V6.5H15L16.5 8.5V6.5H18V9.5H16.5L15 7.5V9.5H13.5Z" fill="white"/>
      <path d="M18.5 9.5V6.5H22V7.5H19.5V7.75H21.5V8.5H19.5V8.75H22V9.5H18.5Z" fill="white"/>
      <path d="M14 5V2H16L17 4L18 2H20V5H19V2.5L17.75 5H16.25L15 2.5V5H14Z" fill="white"/>
    </svg>
  );
}

export function DiscoverLogo({ className = "" }: { className?: string }) {
  return (
    <svg 
      className={className}
      width="25"
      height="16"
      viewBox="0 0 25 16"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <rect width="25" height="16" rx="1" fill="white" />
      <path d="M22 16H1C0.448 16 0 15.552 0 15V11H25V15C25 15.552 24.552 16 24 16H22Z" fill="#F27712"/>
      <path d="M12.5 5C15 5 17 7 17 9.5C17 12 15 14 12.5 14C10 14 8 12 8 9.5C8 7 10 5 12.5 5Z" fill="#F27712"/>
    </svg>
  );
}

