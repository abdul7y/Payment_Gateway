import React, { useState, useEffect } from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { FormField, FormItem, FormLabel, FormControl, FormMessage } from "@/components/ui/form";
import { type Control, type FieldPath, type FieldValues, useWatch } from "react-hook-form";
import { formatCardNumber, detectCardType } from "@/lib/utils/cardValidator";
import { VisaLogo, MastercardLogo, AmexLogo, DiscoverLogo } from "@/assets/cardLogos";

interface CardFormFieldProps<
  TFieldValues extends FieldValues = FieldValues,
  TName extends FieldPath<TFieldValues> = FieldPath<TFieldValues>
> {
  control: Control<TFieldValues>;
  name: TName;
  label: string;
  className?: string;
}

export function CardFormField<
  TFieldValues extends FieldValues = FieldValues,
  TName extends FieldPath<TFieldValues> = FieldPath<TFieldValues>
>({
  control,
  name,
  label,
  className = "",
}: CardFormFieldProps<TFieldValues, TName>) {
  const [activeCardType, setActiveCardType] = useState<string>("");
  const cardNumber = useWatch({
    control,
    name,
  });

  useEffect(() => {
    if (cardNumber) {
      const cleanNumber = cardNumber.replace(/\D/g, '');
      const detectedType = detectCardType(cleanNumber);
      setActiveCardType(detectedType);
    } else {
      setActiveCardType("");
    }
  }, [cardNumber]);

  return (
    <FormField
      control={control}
      name={name}
      render={({ field, fieldState }) => (
        <FormItem className="form-field">
          <FormLabel className="block text-sm font-medium text-gray-700 mb-1">
            {label}
          </FormLabel>
          <div className="relative">
            <FormControl>
              <Input
                {...field}
                value={formatCardNumber(field.value || "")}
                onChange={(e) => {
                  const value = e.target.value;
                  // Let's limit the input to 19 characters (16 digits + 3 spaces)
                  if (value.length <= 19) {
                    field.onChange(e);
                  }
                }}
                placeholder="xxxx xxxx xxxx xxxx"
                className={`input-field w-full px-3 py-2 border border-inputBorder rounded-md text-gray-800 pr-16 ${
                  fieldState.error ? "input-error" : ""
                } ${className}`}
                autoComplete="cc-number"
                aria-invalid={!!fieldState.error}
              />
            </FormControl>
            <div className="absolute right-3 top-1/2 transform -translate-y-1/2 flex items-center space-x-1">
              {!activeCardType && (
                <div className="flex items-center space-x-1">
                  <VisaLogo className="card-logo h-6 w-auto" />
                  <MastercardLogo className="card-logo h-6 w-auto" />
                </div>
              )}
              {activeCardType === "visa" && <VisaLogo className="card-logo h-6 w-auto" />}
              {activeCardType === "mastercard" && <MastercardLogo className="card-logo h-6 w-auto" />}
              {activeCardType === "amex" && <AmexLogo className="card-logo h-6 w-auto" />}
              {activeCardType === "discover" && <DiscoverLogo className="card-logo h-6 w-auto" />}
            </div>
          </div>
          <FormMessage className="error-message" />
        </FormItem>
      )}
    />
  );
}

export function ExpiryFormField<
  TFieldValues extends FieldValues = FieldValues,
  TName extends FieldPath<TFieldValues> = FieldPath<TFieldValues>
>({
  control,
  name,
  label,
  className = "",
}: CardFormFieldProps<TFieldValues, TName>) {
  return (
    <FormField
      control={control}
      name={name}
      render={({ field, fieldState }) => (
        <FormItem className="form-field">
          <FormLabel className="block text-sm font-medium text-gray-700 mb-1">
            {label}
          </FormLabel>
          <FormControl>
            <Input
              {...field}
              value={field.value}
              onChange={(e) => {
                let value = e.target.value.replace(/\D/g, '');
                let formatted = '';
                
                if (value.length > 0) {
                  // Format as MM
                  formatted = value.substring(0, 2);
                  
                  // Add separator and YY if we have more digits
                  if (value.length > 2) {
                    formatted += '/' + value.substring(2, 4);
                  }
                }
                
                field.onChange({ ...e, target: { ...e.target, value: formatted } });
              }}
              placeholder="MM/YY"
              maxLength={5}
              className={`input-field w-full px-3 py-2 border border-inputBorder rounded-md text-gray-800 ${
                fieldState.error ? "input-error" : ""
              } ${className}`}
              autoComplete="cc-exp"
              aria-invalid={!!fieldState.error}
            />
          </FormControl>
          <FormMessage className="error-message" />
        </FormItem>
      )}
    />
  );
}

export function CVVFormField<
  TFieldValues extends FieldValues = FieldValues,
  TName extends FieldPath<TFieldValues> = FieldPath<TFieldValues>
>({
  control,
  name,
  label,
  className = "",
}: CardFormFieldProps<TFieldValues, TName>) {
  return (
    <FormField
      control={control}
      name={name}
      render={({ field, fieldState }) => (
        <FormItem className="form-field">
          <FormLabel className="block text-sm font-medium text-gray-700 mb-1">
            {label}
          </FormLabel>
          <FormControl>
            <Input
              {...field}
              value={field.value}
              onChange={(e) => {
                const value = e.target.value.replace(/\D/g, '');
                field.onChange({ ...e, target: { ...e.target, value } });
              }}
              placeholder="123"
              maxLength={4}
              className={`input-field w-full px-3 py-2 border border-inputBorder rounded-md text-gray-800 ${
                fieldState.error ? "input-error" : ""
              } ${className}`}
              autoComplete="cc-csc"
              aria-invalid={!!fieldState.error}
            />
          </FormControl>
          <FormMessage className="error-message" />
        </FormItem>
      )}
    />
  );
}
