import React from "react";
import { Button } from "@/components/ui/button";
import { CheckCircle } from "lucide-react";

interface ThankYouScreenProps {
  onReset: () => void;
}

export function ThankYouScreen({ onReset }: ThankYouScreenProps) {
  return (
    <div id="thank-you-screen" className="flex flex-col items-center justify-center mx-auto max-w-md">
      {/* Blue header */}
      <div className="w-full bg-blue-600 p-4 flex justify-center rounded-t-md">
        <div className="text-white font-bold text-lg flex items-center">
          Payment Confirmation
        </div>
      </div>
      
      {/* White content area */}
      <div className="w-full bg-white p-6 rounded-b-md shadow-md">
        <div className="text-center mb-6">
          <CheckCircle className="h-16 w-16 mx-auto text-green-500 mb-4" />
          <h2 className="text-xl font-semibold text-gray-800 mb-2">
            Thanks for submitting the details. We will get back to you shortly!
          </h2>
        </div>
      </div>
      
      {/* Footer */}
      <div className="mt-4 text-gray-500 text-sm">
        © 2025 All Rights Reserved
      </div>
      
      {/* Button for resetting the form */}
      <Button 
        id="new-payment-button"
        className="bg-primary hover:bg-blue-700 text-white font-medium py-2 px-6 rounded-md transition duration-200 mt-4"
        onClick={onReset}
      >
        Submit Another Payment
      </Button>
    </div>
  );
}
