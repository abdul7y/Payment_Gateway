import React from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { FormField as ShadcnFormField, FormItem, FormLabel, FormControl, FormMessage } from "@/components/ui/form";
import { type Control, type FieldPath, type FieldValues } from "react-hook-form";

interface FormFieldProps<
  TFieldValues extends FieldValues = FieldValues,
  TName extends FieldPath<TFieldValues> = FieldPath<TFieldValues>
> {
  control: Control<TFieldValues>;
  name: TName;
  label: string;
  placeholder?: string;
  className?: string;
  autoComplete?: string;
  type?: string;
}

export function FormField<
  TFieldValues extends FieldValues = FieldValues,
  TName extends FieldPath<TFieldValues> = FieldPath<TFieldValues>
>({
  control,
  name,
  label,
  placeholder = "",
  className = "",
  autoComplete,
  type = "text",
}: FormFieldProps<TFieldValues, TName>) {
  return (
    <ShadcnFormField
      control={control}
      name={name}
      render={({ field, fieldState }) => (
        <FormItem className="form-field">
          <FormLabel className="block text-sm font-medium text-gray-700 mb-1">
            {label}
          </FormLabel>
          <FormControl>
            <Input
              {...field}
              type={type}
              placeholder={placeholder}
              className={`input-field w-full px-3 py-2 border border-inputBorder rounded-md text-gray-800 ${
                fieldState.error ? "input-error" : ""
              } ${className}`}
              autoComplete={autoComplete}
              aria-invalid={!!fieldState.error}
            />
          </FormControl>
          <FormMessage className="error-message" />
        </FormItem>
      )}
    />
  );
}
