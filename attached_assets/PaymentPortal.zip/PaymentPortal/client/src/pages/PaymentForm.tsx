import React, { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { PaymentFormData, paymentFormSchema } from "@shared/schema";
import { FormField } from "@/components/FormField";
import { CardFormField, ExpiryFormField, CVVFormField } from "@/components/CardFormField";
import { ThankYouScreen } from "@/components/ThankYouScreen";
import { Button } from "@/components/ui/button";
import { Form } from "@/components/ui/form";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Lock, ShieldCheck } from "lucide-react";

export default function PaymentForm() {
  const [showThankYou, setShowThankYou] = useState(false);
  const { toast } = useToast();
  
  const form = useForm<PaymentFormData>({
    resolver: zodResolver(paymentFormSchema),
    defaultValues: {
      firstName: "",
      lastName: "",
      cardNumber: "",
      expiry: "",
      cvv: "",
      nameOnCard: "",
      address: "",
    },
    mode: "onChange",
  });

  const submitPayment = useMutation({
    mutationFn: async (data: PaymentFormData) => {
      const response = await apiRequest("POST", "/api/payment", data);
      return response.json();
    },
    onSuccess: () => {
      setShowThankYou(true);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to process payment information. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: PaymentFormData) => {
    submitPayment.mutate(data);
  };

  const resetForm = () => {
    form.reset();
    setShowThankYou(false);
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4 sm:p-6">
      <div className="w-full max-w-md bg-white rounded-lg shadow-sm border border-gray-100 p-6 sm:p-8">
        <h1 className="text-xl font-semibold text-gray-800 mb-6">Payment Information Form</h1>
        
        {!showThankYou ? (
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
              <div className="space-y-4">
                <FormField
                  control={form.control}
                  name="firstName"
                  label="First Name"
                  autoComplete="given-name"
                />
                
                <FormField
                  control={form.control}
                  name="lastName"
                  label="Last Name"
                  autoComplete="family-name"
                />
                
                <CardFormField
                  control={form.control}
                  name="cardNumber"
                  label="Card Number"
                />
                
                <div className="grid grid-cols-2 gap-4">
                  <ExpiryFormField
                    control={form.control}
                    name="expiry"
                    label="Expiry"
                  />
                  
                  <CVVFormField
                    control={form.control}
                    name="cvv"
                    label="CVV"
                  />
                </div>
                
                <FormField
                  control={form.control}
                  name="nameOnCard"
                  label="Name on Card"
                  autoComplete="cc-name"
                />
                
                <FormField
                  control={form.control}
                  name="address"
                  label="Address"
                  autoComplete="street-address"
                />
              </div>
              
              {/* Security Badge Section */}
              <div className="flex justify-center space-x-4 py-2">
                <div className="flex items-center">
                  <Lock className="h-5 w-5 text-success mr-1" />
                  <span className="text-xs text-gray-600">Secure Payment</span>
                </div>
                <div className="flex items-center">
                  <ShieldCheck className="h-5 w-5 text-success mr-1" />
                  <span className="text-xs text-gray-600">SSL Encrypted</span>
                </div>
              </div>
              
              <Button 
                type="submit"
                className="w-full bg-primary hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-md transition duration-200"
                disabled={submitPayment.isPending}
              >
                {submitPayment.isPending ? "Processing..." : "Confirm"}
              </Button>
            </form>
          </Form>
        ) : (
          <ThankYouScreen onReset={resetForm} />
        )}
      </div>
      
      {/* Powered By */}
      <div className="mt-4 text-center text-gray-500 text-xs">
        Powered by Secure Payment Processing
      </div>
    </div>
  );
}
