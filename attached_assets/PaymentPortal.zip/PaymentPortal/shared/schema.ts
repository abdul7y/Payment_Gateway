import { pgTable, text, serial, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Payment form schema
export const paymentFormSchema = z.object({
  firstName: z.string().min(1, "First name is required"),
  lastName: z.string().min(1, "Last name is required"),
  cardNumber: z.string().min(1, "Card number is required")
    .regex(/^\d{4}\s\d{4}\s\d{4}\s\d{4}$/, "Please enter a valid 16-digit card number"),
  expiry: z.string().min(1, "Expiration date is required")
    .regex(/^\d{2}\/\d{2}$/, "Please use MM/YY format"),
  cvv: z.string().min(1, "CVV is required")
    .regex(/^\d{3,4}$/, "CVV must be 3 or 4 digits"),
  nameOnCard: z.string().min(1, "Name on card is required"),
  address: z.string().min(1, "Address is required"),
});

export type PaymentFormData = z.infer<typeof paymentFormSchema>;
